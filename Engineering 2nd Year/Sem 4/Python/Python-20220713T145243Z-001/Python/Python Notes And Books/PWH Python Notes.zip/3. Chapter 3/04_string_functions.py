myStr = "abcdefghijklmnopqrstuvwxyzaaab"

print(len(myStr))
print(myStr.endswith("xyz"))
print(myStr.startswith("abcd"))
print(myStr.count('ab'))

myStr = "my name is harry name"
print(myStr.capitalize())
print(myStr.find("name"))
print(myStr.replace("name", "date"))