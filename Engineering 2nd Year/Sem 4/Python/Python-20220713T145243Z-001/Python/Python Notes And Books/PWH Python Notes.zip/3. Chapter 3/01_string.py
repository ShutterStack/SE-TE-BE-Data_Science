name = "Adam D'Angelo"
name2 = 'Joh"n'
name3 = '''Twinkle, twinkle, little star
How I wonder what you are
Up above the world so high
Like "a diamond in the sky
Twinkle, twinkle little star'
How I wonder what you are
When the blazing sun is gone
When he nothing shines upon
Then you show your little light
Twinkle, twinkle, all the night
Twinkle, twinkle, little star
How I wonder what you are'''

print(name)
print(type(name))

print(name2)
print(type(name2))

print(name3)
print(type(name3))