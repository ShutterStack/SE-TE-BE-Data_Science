name = "Harry"
print(name)

print(name[4])
print(name[1:4])