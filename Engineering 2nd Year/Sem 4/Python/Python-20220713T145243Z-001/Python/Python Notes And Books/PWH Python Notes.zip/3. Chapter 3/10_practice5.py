letter = "Dear Harry,\n\tThis python course is nice.\nThanks"
print(letter)