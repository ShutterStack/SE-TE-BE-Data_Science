myStr = "This is me   and   I  am a good boy"

print(myStr.find("  "))
print(myStr.find("harry"))