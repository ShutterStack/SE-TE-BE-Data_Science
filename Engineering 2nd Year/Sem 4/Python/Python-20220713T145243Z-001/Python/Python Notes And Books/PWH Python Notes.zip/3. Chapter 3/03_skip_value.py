myStr = "abcdefghijklmnopqrstuvwxyz"

print(myStr[2:6])
print(myStr[1:9])
print(myStr[1:9:3])