def func1():
    print("Hello Harry")
    print("You are good!")
    print("I am another line")


func1()
func1()
func1()
func1()
func1()