def cel2far(cel):
    return (cel * 9/5) + 32

a = cel2far(137) 
print(a)
