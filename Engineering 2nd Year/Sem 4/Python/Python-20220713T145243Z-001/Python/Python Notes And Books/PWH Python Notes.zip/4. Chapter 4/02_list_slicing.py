l1 = [7, 9 , "Harry"]
print(l1[0:3])
print(l1[0:4]) 
print(l1[0:40]) 