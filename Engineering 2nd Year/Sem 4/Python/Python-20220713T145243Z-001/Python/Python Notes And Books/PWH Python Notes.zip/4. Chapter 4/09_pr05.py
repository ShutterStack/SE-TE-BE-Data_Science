tu = (7, 0, 8, 0, 0, 9)
print("The number of zeros in this tuple is", tu.count(0))