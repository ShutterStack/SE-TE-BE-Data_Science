a = (1, 7, 12, 2, 2)
# print(a.count(1))
print(a.index(2))