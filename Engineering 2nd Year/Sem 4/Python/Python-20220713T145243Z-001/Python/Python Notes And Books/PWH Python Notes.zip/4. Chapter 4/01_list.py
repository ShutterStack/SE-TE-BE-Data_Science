a = 12
b = "This is a string"
c = False

myList = [a, b , c, 23.2]
print(myList)
print(type(myList))