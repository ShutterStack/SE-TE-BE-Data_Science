# A very basic sample class
class Employee:
    name = "Harry"
    marks = 34
    center = "Delhi"

harry = Employee() # A basic object
print(harry.marks)
print(harry.center)
print(harry.name)