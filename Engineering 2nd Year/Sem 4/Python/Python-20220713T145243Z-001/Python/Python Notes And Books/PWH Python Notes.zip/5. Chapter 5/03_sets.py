mySet = {1, 34, 53}
mySet.add(45)
mySet.add("1")
print(mySet)
mySet.remove(34)
mySet.add("1")
print(mySet.pop())
print(mySet)
print(len(mySet))