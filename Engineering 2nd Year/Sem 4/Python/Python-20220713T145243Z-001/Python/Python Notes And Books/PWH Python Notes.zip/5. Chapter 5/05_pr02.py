s = set()
# for i in range(8):
s.add(18)
s.add(input("Enter your number: "))
s.add(input("Enter your number: "))
s.add(input("Enter your number: "))
s.add(input("Enter your number: "))
s.add(input("Enter your number: "))
s.add(input("Enter your number: "))
s.add(input("Enter your number: "))
s.add(input("Enter your number: "))

print(s)