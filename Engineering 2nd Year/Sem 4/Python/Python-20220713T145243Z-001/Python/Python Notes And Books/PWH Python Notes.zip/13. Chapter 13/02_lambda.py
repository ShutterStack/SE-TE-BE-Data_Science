# def square(n):
#     return n*n

square = lambda x: x*x
divide = lambda x, y: x/y
print(square(4))
print(divide(4, 2))