friends = ['Rohit', 'Shubh', 'Preeti', 'Neha', 'Disha']

a = " is a friend of ".join(friends)
print(a)