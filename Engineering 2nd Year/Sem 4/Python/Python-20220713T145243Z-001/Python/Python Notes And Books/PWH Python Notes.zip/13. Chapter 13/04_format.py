a = "I am a good boy on {1} and a friend of {0}".format('Earth', 'Harry')
print(a)