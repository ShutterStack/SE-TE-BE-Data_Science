a = [i*7 for i in range(1, 11)]
st = ""
for item in a:
    st += str(item) + '\n'

print(st)