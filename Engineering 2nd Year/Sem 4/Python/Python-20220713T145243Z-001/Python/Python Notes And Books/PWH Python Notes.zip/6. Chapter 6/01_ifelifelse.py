a = 30
if(a>4):
    print("a is greater than 4")
    
if(a>2):
    print("a is greater than 2")
else:
    print("nothing")

