i = 1
sum =0
n = 4
while(i<=n):
    sum += i
    i +=1
print(f"The sum of first {n} natural numbers is {sum}")
