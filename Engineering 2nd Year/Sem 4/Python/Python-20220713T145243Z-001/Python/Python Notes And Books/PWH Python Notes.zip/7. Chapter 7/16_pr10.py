n = 8
for j in range(1, 11):
    i = 11 - j
    print(f"{n} X {i} = {n*i}")