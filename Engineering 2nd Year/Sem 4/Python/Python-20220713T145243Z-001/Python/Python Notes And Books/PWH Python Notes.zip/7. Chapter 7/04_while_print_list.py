a = [1, "apple", 3, 4 , 5, "banana"]
i = 0
while(i<len(a)):
    print(a[i])
    i+=1