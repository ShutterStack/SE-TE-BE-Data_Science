i = 1
while(i<=5):
    print(i)
    i += 1