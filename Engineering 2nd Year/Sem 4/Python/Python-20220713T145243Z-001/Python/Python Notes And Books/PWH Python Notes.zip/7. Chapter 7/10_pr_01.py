num = int(input("Enter the number\n"))

for i in range(10):
    print(f"{num}X{i+1}={num*(i+1)}")