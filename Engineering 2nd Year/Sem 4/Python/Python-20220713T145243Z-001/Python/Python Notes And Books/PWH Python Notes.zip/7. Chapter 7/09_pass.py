for i in range(0, 78):
    pass

print("do something")