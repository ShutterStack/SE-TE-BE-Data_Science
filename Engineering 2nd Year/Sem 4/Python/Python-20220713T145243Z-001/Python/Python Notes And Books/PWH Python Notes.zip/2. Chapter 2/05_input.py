# a = input("Enter your name: ")
# print("Your name is:", a)

a = input("Enter first number: ")
b = input("Enter second number: ")

print("The sum is:", int(a) + int(b))