a = input("Enter something: ")
print("The type of a is:", type(a))